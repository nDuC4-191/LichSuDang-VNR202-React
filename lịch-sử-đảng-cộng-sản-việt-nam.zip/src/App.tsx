/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  History, 
  Users, 
  Flag, 
  ChevronRight, 
  Star, 
  BookOpen,
  ArrowRight,
  Menu,
  X
} from 'lucide-react';

const timelineEvents = [
  {
    year: "1920",
    title: "Sự lựa chọn con đường cứu nước",
    description: "Nguyễn Ái Quốc đọc Sơ thảo lần thứ nhất những luận cương về vấn đề dân tộc và vấn đề thuộc địa của Lênin, tìm thấy con đường giải phóng dân tộc.",
    icon: <History className="w-6 h-6" />
  },
  {
    year: "1925",
    title: "Hội Việt Nam Cách mạng Thanh niên",
    description: "Tháng 6/1925, Nguyễn Ái Quốc thành lập Hội Việt Nam Cách mạng Thanh niên tại Quảng Châu (Trung Quốc), chuẩn bị về chính trị, tư tưởng và tổ chức.",
    icon: <Users className="w-6 h-6" />
  },
  {
    year: "1929",
    title: "Sự ra đời của các tổ chức cộng sản",
    description: "Ba tổ chức cộng sản lần lượt ra đời: Đông Dương Cộng sản Đảng, An Nam Cộng sản Đảng và Đông Dương Cộng sản Liên đoàn.",
    icon: <BookOpen className="w-6 h-6" />
  },
  {
    year: "1930",
    title: "Hội nghị hợp nhất thành lập Đảng",
    description: "Từ ngày 6/1 đến 7/2/1930, Hội nghị hợp nhất các tổ chức cộng sản họp tại Cửu Long (Hương Cảng, Trung Quốc) dưới sự chủ trì của Nguyễn Ái Quốc.",
    icon: <Flag className="w-6 h-6" />
  }
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 bg-[#fdfaf6]/80 backdrop-blur-md border-b border-heritage-red/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-heritage-red rounded-full flex items-center justify-center shadow-lg">
              <Star className="text-heritage-gold w-6 h-6 fill-heritage-gold" />
            </div>
            <span className="font-serif text-xl font-bold tracking-tight hidden sm:block">Lịch sử Đảng CSVN</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-sm font-medium hover:text-heritage-red transition-colors">Trang chủ</a>
            <a href="#timeline" className="text-sm font-medium hover:text-heritage-red transition-colors">Tiến trình</a>
            <a href="#founding" className="text-sm font-medium hover:text-heritage-red transition-colors">Thành lập</a>
            <a href="#significance" className="text-sm font-medium hover:text-heritage-red transition-colors">Ý nghĩa</a>
            <button className="bg-heritage-red text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-red-700 transition-all shadow-md">
              Tìm hiểu thêm
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#fdfaf6] border-b border-heritage-red/10 overflow-hidden"
          >
            <div className="px-4 py-6 space-y-4">
              <a href="#home" onClick={() => setIsOpen(false)} className="block text-lg font-serif">Trang chủ</a>
              <a href="#timeline" onClick={() => setIsOpen(false)} className="block text-lg font-serif">Tiến trình</a>
              <a href="#founding" onClick={() => setIsOpen(false)} className="block text-lg font-serif">Thành lập</a>
              <a href="#significance" onClick={() => setIsOpen(false)} className="block text-lg font-serif">Ý nghĩa</a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default function App() {
  return (
    <div className="min-h-screen selection:bg-heritage-red selection:text-white">
      <Navbar />

      {/* Hero Section */}
      <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute top-0 right-0 -z-10 opacity-10">
          <Star className="w-[600px] h-[600px] text-heritage-red fill-heritage-red rotate-12" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-heritage-red/10 text-heritage-red text-xs font-bold uppercase tracking-wider mb-6">
                <Calendar className="w-3 h-3" />
                <span>3 tháng 2 năm 1930</span>
              </div>
              <h1 className="text-6xl lg:text-8xl font-serif leading-[0.9] mb-8">
                Sự ra đời của <br />
                <span className="text-heritage-red">Đảng Cộng sản</span> <br />
                Việt Nam
              </h1>
              <p className="text-lg text-gray-600 max-w-xl mb-10 leading-relaxed">
                Một bước ngoặt lịch sử vĩ đại, chấm dứt cuộc khủng hoảng về đường lối cứu nước và tổ chức lãnh đạo phong trào yêu nước của nhân dân Việt Nam đầu thế kỷ XX.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="#timeline" className="bg-heritage-red text-white px-8 py-4 rounded-full font-medium hover:bg-red-700 transition-all shadow-xl flex items-center gap-2">
                  Khám phá lịch sử <ArrowRight className="w-4 h-4" />
                </a>
                <a href="#founding" className="border border-heritage-red/20 px-8 py-4 rounded-full font-medium hover:bg-heritage-red/5 transition-all">
                  Hội nghị thành lập
                </a>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="aspect-[4/5] rounded-[2rem] overflow-hidden shadow-2xl relative group">
                <img 
                  src="https://picsum.photos/seed/vietnam-history/800/1000" 
                  alt="Lịch sử Việt Nam" 
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-8 left-8 right-8 text-white">
                  <p className="font-serif italic text-xl">"Đảng ta là đạo đức, là văn minh."</p>
                  <p className="text-sm opacity-80 mt-2">— Chủ tịch Hồ Chí Minh</p>
                </div>
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-heritage-gold rounded-full flex items-center justify-center shadow-xl rotate-12">
                <Star className="text-heritage-red w-16 h-16 fill-heritage-red" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section id="timeline" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl lg:text-5xl font-serif mb-4">Tiến trình lịch sử</h2>
            <div className="w-24 h-1 bg-heritage-red mx-auto" />
          </div>

          <div className="relative">
            <div className="absolute left-1/2 -translate-x-1/2 h-full w-px timeline-line hidden md:block" />
            
            <div className="space-y-24">
              {timelineEvents.map((event, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className={`flex flex-col md:flex-row items-center gap-8 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                >
                  <div className="flex-1 text-center md:text-right w-full">
                    {index % 2 === 0 ? (
                      <div>
                        <span className="text-5xl font-serif text-heritage-red/20 mb-2 block">{event.year}</span>
                        <h3 className="text-2xl font-serif mb-4">{event.title}</h3>
                        <p className="text-gray-600 leading-relaxed">{event.description}</p>
                      </div>
                    ) : null}
                  </div>

                  <div className="relative z-10 w-16 h-16 bg-heritage-red rounded-full flex items-center justify-center shadow-lg text-white shrink-0">
                    {event.icon}
                  </div>

                  <div className="flex-1 text-center md:text-left w-full">
                    {index % 2 !== 0 ? (
                      <div>
                        <span className="text-5xl font-serif text-heritage-red/20 mb-2 block">{event.year}</span>
                        <h3 className="text-2xl font-serif mb-4">{event.title}</h3>
                        <p className="text-gray-600 leading-relaxed">{event.description}</p>
                      </div>
                    ) : null}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Founding Conference Details */}
      <section id="founding" className="py-24 bg-[#fdfaf6]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-[3rem] p-8 lg:p-16 shadow-xl border border-heritage-red/5 overflow-hidden relative">
            <div className="absolute top-0 right-0 p-12 opacity-5">
              <History className="w-64 h-64" />
            </div>
            
            <div className="grid lg:grid-cols-2 gap-16 items-center relative z-10">
              <div>
                <h2 className="text-4xl lg:text-5xl font-serif mb-8">Hội nghị thành lập Đảng</h2>
                <div className="space-y-6 text-gray-600 text-lg leading-relaxed">
                  <p>
                    Dưới sự chủ trì của đồng chí Nguyễn Ái Quốc, Hội nghị hợp nhất các tổ chức cộng sản đã họp từ ngày 6/1 đến ngày 7/2/1930 tại Cửu Long (Hương Cảng, Trung Quốc).
                  </p>
                  <p>
                    Hội nghị đã nhất trí hợp nhất các tổ chức cộng sản thành một đảng duy nhất lấy tên là <strong>Đảng Cộng sản Việt Nam</strong>.
                  </p>
                  <p>
                    Hội nghị thông qua Chánh cương vắn tắt, Sách lược vắn tắt, Chương trình tóm tắt và Điều lệ vắn tắt của Đảng do Nguyễn Ái Quốc soạn thảo. Đây là Cương lĩnh chính trị đầu tiên của Đảng.
                  </p>
                </div>
                <div className="mt-10 grid grid-cols-2 gap-6">
                  <div className="p-6 bg-[#fdfaf6] rounded-2xl">
                    <div className="text-heritage-red font-serif text-3xl mb-1">03/02</div>
                    <div className="text-sm uppercase tracking-wider font-bold opacity-60">Ngày thành lập</div>
                  </div>
                  <div className="p-6 bg-[#fdfaf6] rounded-2xl">
                    <div className="text-heritage-red font-serif text-3xl mb-1">Cửu Long</div>
                    <div className="text-sm uppercase tracking-wider font-bold opacity-60">Địa điểm</div>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <img src="https://picsum.photos/seed/vn1/400/600" className="rounded-2xl shadow-lg grayscale" referrerPolicy="no-referrer" />
                <div className="space-y-4">
                  <img src="https://picsum.photos/seed/vn2/400/300" className="rounded-2xl shadow-lg grayscale" referrerPolicy="no-referrer" />
                  <img src="https://picsum.photos/seed/vn3/400/300" className="rounded-2xl shadow-lg grayscale" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Significance Section */}
      <section id="significance" className="py-24 bg-heritage-red text-white overflow-hidden relative">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-serif mb-6">Ý nghĩa lịch sử</h2>
            <p className="text-white/80 max-w-2xl mx-auto text-lg">
              Sự ra đời của Đảng là một bước ngoặt vô cùng quan trọng trong lịch sử cách mạng Việt Nam.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Chấm dứt khủng hoảng",
                desc: "Chấm dứt thời kỳ khủng hoảng sâu sắc về đường lối cứu nước và giai cấp lãnh đạo cách mạng Việt Nam."
              },
              {
                title: "Thống nhất phong trào",
                desc: "Quy tụ các tổ chức cộng sản thành một khối thống nhất, tạo nên sức mạnh tổng hợp của toàn dân tộc."
              },
              {
                title: "Kết nối quốc tế",
                desc: "Cách mạng Việt Nam trở thành một bộ phận khăng khít của cách mạng vô sản thế giới."
              }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-8 bg-white/10 backdrop-blur-lg rounded-3xl border border-white/20 hover:bg-white/20 transition-all group"
              >
                <div className="w-12 h-12 bg-heritage-gold rounded-full flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                  <Star className="text-heritage-red w-6 h-6 fill-heritage-red" />
                </div>
                <h3 className="text-2xl font-serif mb-4">{item.title}</h3>
                <p className="text-white/70 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-[#fdfaf6] border-t border-heritage-red/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-heritage-red rounded-full flex items-center justify-center">
                <Star className="text-heritage-gold w-4 h-4 fill-heritage-gold" />
              </div>
              <span className="font-serif text-lg font-bold">Lịch sử Đảng CSVN</span>
            </div>
            <div className="flex gap-8 text-sm font-medium text-gray-500">
              <a href="#" className="hover:text-heritage-red transition-colors">Tài liệu tham khảo</a>
              <a href="#" className="hover:text-heritage-red transition-colors">Bản quyền</a>
              <a href="#" className="hover:text-heritage-red transition-colors">Liên hệ</a>
            </div>
            <p className="text-sm text-gray-400">
              © 2026 Website tìm hiểu lịch sử.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
